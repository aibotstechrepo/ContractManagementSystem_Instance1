function AddRecord()
{
		CKEDITOR.instances.IDofEditor.document.getById('TestEdit').setAttribute('contenteditable','true');
}
//contenteditable="false"
// CKEDITOR.on( 'instanceReady', function( ev )
// {
//     alert("CKEditor is loaded");
// });