function test()
{
	alert("called");
}

// CKEDITOR.on( 'instanceReady', function( ev )
// {
//     alert("CKEditor is loaded");
// });